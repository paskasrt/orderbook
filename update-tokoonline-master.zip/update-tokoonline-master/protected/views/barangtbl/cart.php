<?php 
if (ISSET($_SESSION['userlogin']))
{
	header("location:http://localhost/tokoonline/index.php?r=site/cart");
}
?>
<section id="cart_items">
		<div class="container">
			<div class="breadcrumbs">
				<ol class="breadcrumb">
				  <li><a href="#">Home</a></li>
				  <li class="active">Shopping Cart</li>
				</ol>
			</div>
			<div class="table-responsive cart_info">
				<table class="table table-condensed">
					<thead>
						<tr class="cart_menu">
							<td class="image">Item</td>
							<td class="description"></td>
							<td class="price">Price</td>
							<td class="quantity">Quantity</td>
							<td class="total">Total</td>
							<td></td>
						</tr>
					</thead>
					<tbody>
						<?php include('keranjang.php') ?>
					</tbody>
				</table>
			</div>
		</div>
	</section> <!--/#cart_items-->