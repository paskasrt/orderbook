<?php
/* @var $this PelanggantblController */
/* @var $model Pelanggantbl */

?>

<?php $this->renderPartial('produk_detail_info', array('model'=>$model)); ?>