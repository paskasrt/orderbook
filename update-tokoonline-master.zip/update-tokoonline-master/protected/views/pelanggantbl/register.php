<?php
/* @var $this PelanggantblController */
/* @var $model Pelanggantbl */

?>


<?php $this->renderPartial('_regform', array('model'=>$model)); ?>