<footer id="footer"><!--Footer-->	
		<div class="footer-widget">
			<div class="container">
				<div class="row">
					<img align="center" src="<?php echo Yii::app()->theme->baseUrl;?>/images/home/Header.jpg" alt="" />
					
				</div>
			</div>
		</div>
		
		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<p class="pull-left">Copyright � 2014 Fandi Ahmad Rizal.</p>
					<p class="pull-right">Designed by <span><a target="_blank" href="http://www.themeum.com">Themeum</a></span></p>
				</div>
			</div>
		</div>
		
	</footer><!--/Footer-->
	

  
    <script src="<?php echo Yii::app()->theme->baseUrl;?>/js/jquery.js"></script>
	<script src="<?php echo Yii::app()->theme->baseUrl;?>/js/bootstrap.min.js"></script>
	<script src="<?php echo Yii::app()->theme->baseUrl;?>/js/jquery.scrollUp.min.js"></script>
	<script src="<?php echo Yii::app()->theme->baseUrl;?>/js/price-range.js"></script>
    <script src="<?php echo Yii::app()->theme->baseUrl;?>/js/jquery.prettyPhoto.js"></script>
    <script src="<?php echo Yii::app()->theme->baseUrl;?>/js/main.js"></script>
</body>
</html>