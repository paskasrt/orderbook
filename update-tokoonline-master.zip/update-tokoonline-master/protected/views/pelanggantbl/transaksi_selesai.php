<table width="100%" border="0" cellpadding="0" cellspacing="0" class="Area_Informasi">
    <tr>
      <th width="350" align="left" valign="middle" class="Teks_Transaksi" scope="col">Terima kasih untuk pesanan Anda,</th>
    </tr>
    <tr>
      <th colspan="2" align="left" valign="top" class="Teks_Testi" scope="col"><hr /></th>
    </tr>
    <tr>
      <td colspan="2" align="center" valign="top">
  </td>
</tr>
    <tr>
      <th colspan="2" align="left" valign="top">Faktur :<?php include "faktur_selesai.php"; echo '<font color="#0000FF" size="-">'.$faktur.''; ?></th>
    </tr>
    <tr>
      <th colspan="2" align="left" valign="top">&nbsp;</th>
    </tr>
    <tr>
      <th colspan="2" align="left" valign="top">Mohon konfirmasi via sms ke nomor +6289667917114 setelah Anda melakukan pembayaran, dengan <br />
        <br />
        format:�<strong >(NOMOR_ORDER),(BANK_TUJUAN),(JUMLAH)</strong><br />
        contohnya:�<strong >250805,BCA,215.000</strong></th>
    </tr>
    <tr>
      <th colspan="2" align="left" valign="top">&nbsp;</th>
    </tr>
    <tr>
      <th colspan="2" align="left" valign="top">Total pesanan yang harus dibayar adalah�<em >Rp <?php include "kerantang_total_selesai.php" ?></em>. </th>
    </tr>
    <tr>
      <th colspan="2" align="left" valign="top">&nbsp;</th>
    </tr>
    <tr>
      <th colspan="2" align="left" valign="top"><strong>Pesanan akan kami cancel apabila dalam 2x24 jam belum kami terima pembayarannya.</strong><br />
        <br />
        Pembayaran dapat ditujukan ke salah satu rekening di bawah ini:<br />
        <br />
        <strong>Nama Pemilik Rekening: <span>Fandi Ahmad</span></strong><br />
        <br />
        <strong>BCA</strong><br />
        Norek: <span >0123456789</span><br />
        Cabang: Semarang<br />
        <br />
        <strong>Bank Mandiri</strong><br />
        Norek: 0123456789<br />
        Cabang: Semarang<br />
        <br />
       </th>
    </tr>
    <tr>
      <th colspan="2" align="left" valign="top"><hr /></th>
    </tr>
    <tr>
      <th colspan="2" align="left" valign="top" ><span>Pesanan sudah kami terima, barang akan dikirim 1 hari setelah penerimaan pembayaran.</span></th>
    </tr>
	<br><br><br>
  </table>