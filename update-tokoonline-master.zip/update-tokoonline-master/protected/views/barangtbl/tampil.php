<?php
/* @var $this PelanggantblController */
/* @var $model Pelanggantbl */

?>


<?php $this->renderPartial('tampilproduk', array('dataProvider'=>$dataProvider)); ?>
